$(document).ready(function() {
    $('.nav-trigger').click(function() {
        $('.side-nav').toggleClass('visible');
    });
});
$('div').on('click', function() {
    $(this).toggleClass('show-description');
});
